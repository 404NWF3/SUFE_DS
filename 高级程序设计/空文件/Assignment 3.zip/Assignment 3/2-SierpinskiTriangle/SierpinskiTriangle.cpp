/*
 * File: SierpinskiTriangle.cpp
 * ----------------------------
 * Name: [TODO: enter name here]
 * This file is the starter code for the Sierpinski Triangle problem 
 * from Assignment #3.
 * [TODO: extend the documentation]
 */

/*
 * File: SierpinskiTriangle.cpp
 * Assignment #3.
 */
#include <iostream>
#include "gwindow.h"
#include "console.h"
#include "simpio.h"
using namespace std;

/* Function prototypes */
void drawSierpinskiTriangle(GWindow & gw, double x, double y, double size, int order);

/* Constants */
const double WINDOW_WIDTH = 700;
const double WINDOW_HEIGHT = 470;
const double COS60 = sqrt(3.0) / 2;
const double SIZE = 520;
//const int ORDER = 4;

/* Main program */
int main()
{
    while(true)
    {
        int order = getInteger("Please input the order(>0):");
        if (order <= 0)
        {
            cout<<"Program finished !";
            break;
        }
        GWindow gw(WINDOW_WIDTH, WINDOW_HEIGHT);
        gw.setLocation(50,50);
        gw.setColor("Black");
        double x0 = (WINDOW_WIDTH - SIZE) / 2;
        double y0 = WINDOW_HEIGHT - (WINDOW_HEIGHT - SIZE * COS60) / 2;
        drawSierpinskiTriangle(gw, x0, y0, SIZE, order);
    }
    return 0;
}

/*
 * Function: drawSierpinskiTriangle
 * Usage: drawSierpinskiTriangle(gw, x, y, size, order);
 * -----------------------------------------------------
 * Draws a Sierpinski Triangle of the specified size and order.
 * The upper left corner of the triangle is at the point (x, y).
 */

void drawSierpinskiTriangle(GWindow & gw, double x, double y, double size, int order)
{
   // TODO: Delete this line and the next seven lines, then implement this function.
   // You may use the function : void drawLine(double x0, double y0, double x1, double y1);
   // Usage: gw.drawLine(100, 100, 200, 200);
    (void) gw;
    (void) x;
    (void) y;
    (void) size;
    (void) order;
}

