#pragma once

namespace MiniGUI {
    namespace Detail {
        [[ noreturn ]] void autograderMain();
    }
}
