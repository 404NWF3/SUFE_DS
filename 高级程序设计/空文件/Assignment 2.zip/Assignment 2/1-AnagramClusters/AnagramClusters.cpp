/*
 * File: AnagramClusters.cpp
 * --------------------
 * Name: [TODO: enter name here]
 * This file is the starter project for the Anagram Clusters problem
 * on Assignment #2.
 * [TODO: extend the documentation]
 */

#include <iostream>
#include <string>
#include "console.h"
#include "lexicon.h"
#include "simpio.h"
#include "strlib.h"
#include "map.h"
using namespace std;

/* Function prototypes */

string sortedVersionOf(const string& input);

/* Main program */

int main()
{
    Lexicon english("EnglishWords.txt");

    Map<string, Lexicon> anagramClusters;

    /* Distribute words into their anagram clusters by using
     * the handy map autoinsertion feature.
     * [TODO: fill the code]
     */


    while (true) {
        string word = getLine("Enter a word: ");

        /* The key we'll use will be the sorted version of the word.
         * Question to ponder: why convert to lower case, then
         * sort, rather than the other way around?
         */
        string key = sortedVersionOf(toLowerCase(word));

        if (anagramClusters.containsKey(key)) {
            cout << anagramClusters[key] << endl;
        } else {
            cout << "Opps, such words are not to be found here!" << endl;
        }
    }
    return 0;
}


/**
 * Given a word, returns a string formed by sorting the letters
 * in that word.
 *
 * @param word The input word
 * @return A sorted version of the word
 */
string sortedVersionOf(const string& input) {
    /* This algorithm is an implementation of an algorithm called
     * "Counting Sort." It's described in the slides 05 for Lecture.
     */

    /* Build a frequency table of the letters in the word.
     * [TODO: fill the code]
     */


    string result;
    /* Iterate over the frequency table and build the result
     * string from the information it contains.
     * [TODO: fill the code]
     */

    return result;

}



























