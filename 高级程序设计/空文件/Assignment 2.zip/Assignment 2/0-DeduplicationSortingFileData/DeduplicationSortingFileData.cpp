/*
 * File: sortingfiledata.cpp
 * This program sorts integers read from the text file.
 */

#include <fstream>
#include <string>
#include <cctype>
#include "error.h"
#include "filelib.h"
#include "console.h"
#include "simpio.h"

using namespace std;

int stringToInt(string s);
void sortArray(int data[], int counter);
void displayArray(int data[], int counter);

/* Main program */

int main(){

    // Here, we assume that the number of integers in raw-data.txt does not exceed 100
    int data[100], counter = 0;

    // ------------ Beginning of Task 1  ------------
    // Open text format file as input file stream
    // TODO: fill the code


    // sort the array
    sortArray(data,counter);
    // Open binary format file as output file stream
    // TODO: fill the code


    // ---------------  End of Task 1  --------------

    // ------------ Beginning of Task 2  ------------
    // Read the data from sorted-data.bin, calaulate the median and output to the screen.
    // Open binary format file as input file stream
    // TODO: fill the code



    // ---------------  End of Task 2  --------------
    return 0;
}

void sortArray(int data[], int counter)
{
    for(int i = 0; i < counter-1; i++)
        for(int j = 0; j < counter-i-1; j++){
            if (data[j] > data[j+1]){
                int temp = data[j];
                data[j] = data[j+1];
                data[j+1] = temp;
            }
        }
}

void displayArray(int data[], int counter)
{
    for(int i = 0; i < counter; i++) {
           cout << data[i] << "-";
    }
    cout << endl;
}

int stringToInt(string s)
{
    int sum = 0;
    for(unsigned int i = 0; i < s.length(); i++){
        if(isdigit(s[i])){
            sum *= 10;
            sum += (s[i] - '0');
        }
        else{
            cout << "data error!" << endl;
            return 0;
        }
    }
    return sum;
}
