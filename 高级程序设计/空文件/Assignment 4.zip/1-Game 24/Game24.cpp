/*
 * File: Game 24.cpp
 * ----------------------------
 * Name: [TODO: enter name here]
 * This file is the starter code for the Game 24 problem
 * from Assignment #4.
 * [TODO: extend the documentation]
 */

#include <string>
#include "console.h"
#include "error.h"
#include "simpio.h"
#include "tokenscanner.h"
#include "vector.h"
#include "set.h"
#include "strlib.h"
#include "card.h"
#include "display.h"

using namespace std;

/* Constants */
const int BIGNUM = 24;

Set<string> countTwentyFours(Vector<Card> & cards);

int main(){
    initGraphics("GAME 24");
    while (true){
        // string handCardsString = "5C 10S 4H 9C";
        string handCardsString = getLine("Please input a hand of Cards:");
        if (handCardsString == "") break;
        TokenScanner scanner(handCardsString);
        scanner.ignoreWhitespace();
        Vector<Card> cards;
        bool isLegalCard = true;
        while (scanner.hasMoreTokens()) {
            string tokenString = scanner.nextToken();
            Card handCard = Card(tokenString);
            if(!handCard.fail())
               cards.add(handCard);
            else
               isLegalCard = false;
        }
        int cardsNum = cards.size();
        if (isLegalCard && cardsNum > 1 && cardsNum < 7){
            Set<string> solutionsStrings = countTwentyFours(cards);
            displayHandCards(handCardsString, cardsNum);
            displaySolutions(solutionsStrings, cardsNum);
        }
        else
            cout << "Please give at least 2 cards, up to 6 cards!" << endl << endl;
    }
    cout<<endl<<"Game Over and the windows will be closed in a few seconds..."<<endl;
    pause(3000);
    closeGraphics();
    return 0;
}

Set<string> countTwentyFours(Vector<Card> & cards){
    //   TODO: modify the code and implement the recursive strategy.
    Set<string> solutionsStrings = {};
    solutionsStrings += "( ( ( 5C + 10S ) - 9C ) * 4H ) ";
    solutionsStrings += "( ( 10S - ( 9C - 5C ) ) * 4H )";
    solutionsStrings += "( ( 5C + ( 10S - 9C ) ) * 4H )";
    solutionsStrings += "( ( 9C - 5C ) * ( 10S - 4H ) )";
    return solutionsStrings;
}






