/*
 * File: NumericConversion.cpp
 * ---------------------------
 * Name: [TODO: enter name here]
 * This file is the starter project for the numeric-conversion problem
 * in which you implement the functions intToString and stringToInt.
 * [TODO: rewrite the documentation]
 */

#include <iostream>
#include <string>
#include "console.h"
using namespace std;

/* Function prototypes */

string intToString(int n);
int stringToInt(string str);

/* Main program */

int main() {

   cout << "Integer 123 ----> " << intToString(123) << endl;
   cout << "Integer -42 ----> " << intToString(-42) << endl;
   cout << "String 671 ----> " << stringToInt("671") << endl;
   cout << "String -99 ----> " << stringToInt("-99") << endl;
   return 0;
}

string intToString(int n)
{
   // [TODO: modify and fill in the code]
   return "";
}

int stringToInt(string str)
{
   // [TODO: modify and fill in the code]
   return 0;
}
